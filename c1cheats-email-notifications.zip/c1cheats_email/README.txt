C1CHEATS DIGITAL SHOP — EMAIL ORDER REQUESTS

Files:
- index.html
- styles.css
- script.js

WHAT THIS VERSION DOES
- Customers can browse products and add them to the cart.
- The checkout button opens an order-request form.
- The customer enters their name and email address.
- The selected products and order details are sent to:
  anthonyrompeabuelita123@gmail.com
- No payment is taken. An email request is NOT proof of payment or a completed sale.

EMAIL SETUP (REQUIRED)
This static GitHub Pages site uses FormSubmit to forward order-request emails.
1. Upload these three website files to your GitHub Pages repository, replacing the old versions.
2. Open the published site and submit one test order request using an email address you control.
3. Check anthonyrompeabuelita123@gmail.com for FormSubmit's activation/confirmation email.
4. Click the activation link in that email. FormSubmit will not forward future submissions until the recipient is activated.
5. Submit another test request and confirm that the email arrives. Check Spam/Junk if needed.

IMPORTANT
- FormSubmit is a third-party service; its availability and terms apply.
- The recipient email is visible in the website's public JavaScript. This is normal for this type of form-forwarding endpoint, but it can attract spam. Do not put passwords, private keys, payment-card data, or other secrets in the site.
- This form does not verify payments, reserve stock, authenticate customers, or deliver products.
- Do not describe a request as a paid order. Confirm payment separately if you ever add a legitimate payment provider.
- Only list products and software you are authorized to distribute.
